var __screenWidth = $(window).width(); 
$('#containner').css('width',800); 
$('#containner').css('height',1000); 
var __containnerLeft = (__screenWidth - parseInt($('#containner').css('width'))) / 2; 
$('#containner').css({ 
'left': __containnerLeft, 
'top': 0, 
'z-index': 0, 
'background': '#' 
}); 
$('#div0').css({ 
'left':75, 
'top':69, 
'width':152, 
'height':103, 
'background': '#B5FF36', 
}); 
$('#div1').css({ 
'left':264, 
'top':50, 
'width':173, 
'height':210, 
'background': '#B5D8FF', 
}); 
$('#div2').css({ 
'left':477, 
'top':166, 
'width':40, 
'height':87, 
'background': '#AE80FF', 
}); 
$('#div3').css({ 
'left':553, 
'top':204, 
'width':12, 
'height':29, 
'background': '#1FFF69', 
}); 
$('#div4').css({ 
'left':133, 
'top':285, 
'width':146, 
'height':125, 
'background': '#8FC7FF', 
}); 
$('#div5').css({ 
'left':378, 
'top':316, 
'width':175, 
'height':146, 
'background': '#C48AFF', 
}); 
$('#div6').css({ 
'left':291, 
'top':295, 
'width':53, 
'height':84, 
'background': '#73E8FF', 
}); 
$('#div7').css({ 
'left':619, 
'top':316, 
'width':0, 
'height':0, 
'background': 'false', 
}); 
$('#div8').css({ 
'left':191, 
'top':211, 
'width':0, 
'height':0, 
'background': 'false', 
}); 
